# LIFE QUEST — GamerKie Edition

A playable, dependency-free 2D motivational platformer starter built with HTML5 Canvas and JavaScript ES modules.

## Run locally
Because this project uses JavaScript modules, serve the folder through a local web server (not `file://`).
- VS Code: install/use Live Server and open `index.html`.
- Python: `python -m http.server 8000`, then open `http://localhost:8000`.

## Deploy to GitHub Pages
1. Upload the complete `life-quest` folder contents to the repository root (or keep them in a project folder).
2. In GitHub: Settings → Pages → deploy from your chosen branch and folder.
3. Open the published `index.html` URL.

## Blogger
Host this project on GitHub Pages, then embed the published game URL in a Blogger HTML view using a responsive iframe. Blogger does not reliably run a multi-file project pasted as one post.

## Controls
- Move: A/D or Left/Right
- Jump: Space / W / Up (press again for double jump)
- Slide: S / Down
- Attack: X
- Pause: Escape

On touch devices, use the on-screen controls.

## Current build
This first playable build includes a working start/continue flow, generated platform layout, coins, roaming enemies, hazards, double jump, attack, health, level completion, motivational quote/lesson, XP/coin rewards, and LocalStorage save data. It is the foundation release; additional modes, character skins, checkpoint mechanics, richer world-specific art/audio and expanded progression are planned for subsequent build steps.
